import os

file_name = "demo.txt";
abs_path = os.path.abspath(file_name);
print("abs_path:{}".format(abs_path));